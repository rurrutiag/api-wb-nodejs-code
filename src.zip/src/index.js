// src/index.js

// Importando librerías necesarias
import express from 'express';
// import Redis from 'ioredis'; // Llegará el momento de reemplazar cache por Redis
import dotenv from 'dotenv';
import cors from 'cors';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer } from 'http';

import { getBusinessFlow, sendMessage, logUserInteraction } from './tools.js';

import initializeCache from './functions/initialize-cache.js';

dotenv.config();

// Inicializar
const app = express();
const PORT = process.env.PORT || 3001;
const corsOrigin = process.env.CORS_ORIGIN || true;
// const redis = new Redis();

// Obtener el directorio actual desde import.meta.url
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(express.json()); // Analizar JSON en solicitudes  
app.use(cors({ origin: corsOrigin, methods: 'GET,HEAD,PUT,PATCH,POST,DELETE', credentials: true }));  
app.use(express.static(path.join(__dirname, '../public'))); // Servir archivos estáticos  

// Middleware para registrar solicitudes  
app.use((req, res, next) => {  
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);  
    next();  
});  

// Si alguien hace una solicitud a la URL base '/', servir el archivo 'index.html'
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '../public/index.html'));
});

app.post("/webhook", async (req, res) => {
    try {
        const incomingChange = req.body.entry?.[0]?.changes?.[0]?.value | null;
        const incomingMessage = incomingChange.messages?.[0];

        if (!incomingMessage) return res.sendStatus(400);

        // Número del usuario que envía el mensaje
        const senderNumber = incomingMessage.from;

        // ID del número de WB
        const whatsappNumber = incomingChange.metadata.phone_number_id;

        // El mensaje del usuario
        const userMessage = incomingMessage.text?.body?.trim();

        // Validar si existe una sesión activa para este usuario en este número de WhatsApp Business
        const sessionKey = `${whatsappNumber}-${senderNumber}`;

        if (activeSessions[sessionKey]) {
            const { businessId, flow, currentQuestion, businessConfig } = activeSessions[sessionKey];

            // Procesar la respuesta y avanzar en el flujo
            const userResponse = userMessage;
            await logUserInteraction(senderNumber, businessId, currentQuestion.text, userResponse);

            const nextQuestionId = currentQuestion.next_question[userResponse];
            if (nextQuestionId) {
                const nextQuestion = flow.questions.find((q) => q.id === nextQuestionId);
                activeSessions[sessionKey].currentQuestion = nextQuestion;
                await sendMessage(senderNumber, nextQuestion.text, businessConfig);
            } else {
                const resultMessage = flow.results[userResponse] || "Gracias por participar.";
                await sendMessage(senderNumber, resultMessage, businessConfig);
                delete activeSessions[sessionKey];
            }  
        } else {
            // Iniciar un nuevo flujo
            const businessFlow = await getBusinessFlow(userMessage);
            
            if (!businessFlow) {
                await sendMessage(
                    senderNumber,
                    "Lo siento, no entendí tu mensaje. Por favor, utiliza una palabra clave válida.",
                    { whatsapp_phone_id: whatsappNumber, access_token: process.env.DEFAULT_ACCESS_TOKEN }
                );
                return res.sendStatus(200);
            }
            
            const businessConfig = {
                whatsapp_phone_id: businessFlow.whatsapp_phone_id,
                access_token: businessFlow.access_token,
            };

            const flow = businessFlow.flow_json;

            const firstQuestion = flow.questions[0];
            activeSessions[sessionKey] = {
                businessId: businessFlow.business_id,
                flow,
                currentQuestion: firstQuestion,
                businessConfig,
            };

            await sendMessage(
                senderNumber,
                firstQuestion.text,
                businessConfig
            );
        }
        res.sendStatus(200);
    } catch (error) {
        console.error("Error procesando webhook:", error);
        res.sendStatus(500);
    }
});

// Endpoint para verificar el webhook
app.get("/webhook", (req, res) => {
    const VERIFY_TOKEN = process.env.VERIFY_TOKEN;
    const mode = req.query["hub.mode"];
    const token = req.query["hub.verify_token"];
    const challenge = req.query["hub.challenge"];

    if (mode && token === VERIFY_TOKEN) {
        res.status(200).send(challenge);
    } else {
        res.sendStatus(403);
    }
});

// Middleware para manejar errores 404 (páginas no encontradas)
app.use((req, res, next) => {
    res.status(404).sendFile(path.join(__dirname, '../public/error.html'));
});

async function startServer() {
    try {
        // Crear el servidor
        const server = createServer(app);
        server.on('error', (error) => {
            if (error.code === 'EADDRINUSE'){
                console.log(`Puerto ${PORT} en uso`);
                console.error('Error al iniciar el servidor', error.message);
                process.exit(1);
            }
        });
        // Servidor escuchando PORT
        server.listen(PORT, '0.0.0.0', () => {
            console.log(`Servidor corriendo en puerto ${PORT}`);
        });
        // Cache initialize
        initializeCache()
            .then( () => {
                console.log("Cache inicializado");
            })
            .catch((error) => {
                console.error("Error al inicializar cache:", error);
            });
        
    } catch (error) {
        console.error('Error en cargar certificado', error);
    }
}

startServer();